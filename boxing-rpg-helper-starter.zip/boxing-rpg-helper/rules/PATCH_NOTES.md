# Patch Notes

## v4.1 (Aug 22, 2025)
- 0 Stamina penalty: −2 to all rolls until stamina is recovered.
- +1 Stamina on successful block/defense.
- Tempo tie rule: both fighters lose 1 Stamina and reroll immediately.
- Attack consumes the full minute; Taunt/Move/IQ/Recover consume one Tempo.
- Crit rules: PvP = margin +5; Solo = Nat 12; Crit Fail (Solo) = Nat 2.
- Move + Attack allowed in the same Tempo (pay stamina for both).
